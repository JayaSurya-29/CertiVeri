import React, { useState } from 'react';
import { BuildingOfficeIcon, DocumentArrowUpIcon, CodeBracketIcon, CheckCircleIcon, ExclamationTriangleIcon, FingerPrintIcon, CircleStackIcon } from './icons/Icons';
import Card from './common/Card';
import Spinner from './common/Spinner';
import { CertificateData } from '../types';
import { extractDetailsFromImage } from '../services/geminiService';

interface InstitutionPortalProps {
  verifiedCertificates: CertificateData[];
  addCertificate: (cert: CertificateData) => void;
}

const InstitutionPortal: React.FC<InstitutionPortalProps> = ({ verifiedCertificates, addCertificate }) => {
  // States for Bulk Upload
  const [bulkFile, setBulkFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadStatus, setUploadStatus] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [addWatermark, setAddWatermark] = useState<boolean>(true);

  // States for separate watermarking action
  const [watermarkFile, setWatermarkFile] = useState<File | null>(null);
  const [isWatermarking, setIsWatermarking] = useState<boolean>(false);
  const [watermarkStatus, setWatermarkStatus] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // States for Certificate Registry
  const [registryFile, setRegistryFile] = useState<File | null>(null);
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [registryStatus, setRegistryStatus] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const handleBulkFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setUploadStatus(null);
    const file = event.target.files?.[0] || null;
    setBulkFile(file);
  };

  const handleWatermarkFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setWatermarkStatus(null);
    const file = event.target.files?.[0] || null;
    setWatermarkFile(file);
  };

  const handleRegistryFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRegistryStatus(null);
    const file = event.target.files?.[0] || null;
    setRegistryFile(file);
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = error => reject(error);
    });
  };

  const handleBulkUpload = () => {
    if (!bulkFile) {
      setUploadStatus({ message: 'Please select a file to upload.', type: 'error' });
      return;
    }

    setIsUploading(true);
    setUploadStatus(null);

    // Simulate processing time
    const uploadTime = addWatermark ? 2500 : 1500;

    setTimeout(() => {
      setIsUploading(false);
      const successMessage = addWatermark
        ? `Successfully uploaded and watermarked "${bulkFile.name}". Records are being processed.`
        : `Successfully uploaded "${bulkFile.name}". Records are being processed.`;
      
      setUploadStatus({
        message: successMessage,
        type: 'success',
      });
      setBulkFile(null);
      
      const fileInput = document.getElementById('bulk-upload') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
    }, uploadTime);
  };

  const handleApplyWatermark = () => {
    if (!watermarkFile) {
      setWatermarkStatus({ message: 'Please select a file to apply watermark.', type: 'error' });
      return;
    }

    setIsWatermarking(true);
    setWatermarkStatus(null);

    setTimeout(() => {
      setIsWatermarking(false);
      setWatermarkStatus({
        message: `Successfully applied watermark to "${watermarkFile.name}".`,
        type: 'success',
      });
      setWatermarkFile(null);
      
      const fileInput = document.getElementById('watermark-upload') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
    }, 2000);
  };

  const handleRegisterCertificate = async () => {
    if (!registryFile) {
      setRegistryStatus({ message: 'Please select a certificate file.', type: 'error' });
      return;
    }
    setIsRegistering(true);
    setRegistryStatus(null);

    try {
      const base64Image = await fileToBase64(registryFile);
      const extractedData = await extractDetailsFromImage(base64Image, registryFile.type);

      // Validate extracted data
      if (!extractedData.id || !extractedData.studentName || !extractedData.degree) {
        throw new Error("AI could not extract essential details (ID, Name, Degree). Please use a clearer file.");
      }

      // Check for duplicates
      if (verifiedCertificates.some(cert => cert.id === extractedData.id)) {
        throw new Error(`A certificate with ID "${extractedData.id}" is already registered.`);
      }

      addCertificate(extractedData as CertificateData);
      setRegistryStatus({ message: `Successfully registered certificate for ${extractedData.studentName}.`, type: 'success' });
      setRegistryFile(null);
      const fileInput = document.getElementById('registry-upload') as HTMLInputElement;
      if (fileInput) fileInput.value = '';

    } catch (error) {
      setRegistryStatus({ message: error instanceof Error ? error.message : 'An unknown error occurred.', type: 'error' });
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <div className="space-y-12">
      <div className="text-center">
        <h1 className="text-4xl font-extrabold text-brand-primary">Institution Portal</h1>
        <p className="mt-2 text-lg text-text-secondary">Securely manage and upload your institution's certificate records.</p>
      </div>

      {/* Primary Action: Certificate Registry Management */}
      <div className="bg-base-100 p-8 rounded-2xl shadow-xl border border-brand-primary/20">
        <div className="flex items-center text-brand-primary mb-4">
            <CircleStackIcon className="h-10 w-10 mr-4 flex-shrink-0" />
            <div>
                <h2 className="text-3xl font-bold">Certificate Registry Management</h2>
                <p className="text-text-secondary mt-1">
                    Add new, authentic certificates to the verifiable database to be used as the source of truth.
                </p>
            </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
            {/* Left Side: Upload and Register */}
            <div className="bg-base-200 p-6 rounded-lg border border-base-300">
                <div>
                    <h3 className="text-lg font-semibold text-text-primary">Step 1: Upload Certificate</h3>
                    <p className="text-sm text-text-secondary mb-4">Select the image or PDF file of the authentic certificate.</p>
                    <input 
                        id="registry-upload" 
                        type="file" 
                        accept="image/png, image/jpeg, image/webp, application/pdf"
                        onChange={handleRegistryFileChange}
                        className="block w-full text-sm text-text-secondary file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-primary file:text-white hover:file:bg-brand-secondary cursor-pointer"
                    />
                </div>
                <div className="mt-6">
                    <h3 className="text-lg font-semibold text-text-primary">Step 2: Register to Database</h3>
                    <p className="text-sm text-text-secondary mb-4">Our AI will extract the details. Click below to confirm and add the record to the database.</p>
                    <button 
                        onClick={handleRegisterCertificate}
                        disabled={!registryFile || isRegistering}
                        className="w-full bg-brand-primary text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center hover:bg-brand-secondary transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                        {isRegistering ? (
                        <>
                            <Spinner size="sm" />
                            <span className="ml-2">Extracting & Registering...</span>
                        </>
                        ) : (
                        'Register Certificate'
                        )}
                    </button>
                    {registryStatus && (
                        <div className={`mt-4 p-3 rounded-lg text-sm flex items-center space-x-2 ${
                        registryStatus.type === 'success' ? 'bg-green-100 text-status-success' : 'bg-red-100 text-status-danger'
                        }`}>
                        {registryStatus.type === 'success' 
                            ? <CheckCircleIcon className="h-5 w-5" /> 
                            : <ExclamationTriangleIcon className="h-5 w-5" />}
                        <span className="flex-1">{registryStatus.message}</span>
                        </div>
                    )}
                </div>
            </div>
            {/* Right Side: Current Certificates */}
            <div className="max-h-96 overflow-y-auto">
                <h3 className="font-semibold text-text-primary mb-2">Current Registered Certificates ({verifiedCertificates.length})</h3>
                <div className="border border-base-300 rounded-lg">
                    <table className="w-full text-sm">
                        <thead className="bg-base-200 sticky top-0">
                            <tr>
                                <th className="p-2 text-left text-text-secondary font-semibold">Student Name</th>
                                <th className="p-2 text-left text-text-secondary font-semibold">Certificate ID</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-base-300">
                            {verifiedCertificates.map(cert => (
                                <tr key={cert.id}>
                                    <td className="p-2">{cert.studentName}</td>
                                    <td className="p-2 font-mono text-xs">{cert.id}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
      </div>
      
      {/* Additional Tools Section */}
      <div>
        <h2 className="text-3xl font-bold text-text-primary mb-6 text-center border-t border-base-300 pt-12">Additional Tools</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
            <div className="flex items-center text-brand-primary mb-4">
                <DocumentArrowUpIcon className="h-8 w-8 mr-3" />
                <h2 className="text-2xl font-bold">Bulk Certificate Upload</h2>
            </div>
            <p className="text-text-secondary mb-4">
                Efficiently upload records for multiple graduates at once using a structured CSV or a multi-page PDF file. This ensures your historical data is accurately reflected in the verification system.
            </p>
            <div className="p-6 bg-base-200 rounded-lg border border-base-300">
                <label htmlFor="bulk-upload" className="block text-sm font-medium text-text-primary mb-2">
                Upload CSV or PDF File
                </label>
                <div className="flex items-center space-x-4">
                <input 
                    id="bulk-upload" 
                    type="file" 
                    accept=".csv,application/pdf"
                    onChange={handleBulkFileChange}
                    className="block w-full text-sm text-text-secondary file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-primary file:text-white hover:file:bg-brand-secondary cursor-pointer"
                />
                </div>
                <div className="mt-3 text-xs text-text-secondary">
                    <p>For bulk data, <a href="#" className="text-brand-primary hover:underline font-medium">download the CSV template</a>.</p>
                    <p className="mt-1">For PDF uploads, please ensure one certificate per page.</p>
                </div>
                <div className="mt-4 flex items-center">
                <input
                    id="add-watermark"
                    type="checkbox"
                    checked={addWatermark}
                    onChange={(e) => setAddWatermark(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300 text-brand-primary focus:ring-brand-primary"
                />
                <label htmlFor="add-watermark" className="ml-3 text-sm text-text-secondary">
                    Add secure digital watermark (enhances security)
                </label>
                </div>
            </div>
            
            {uploadStatus && (
                <div className={`mt-4 p-3 rounded-lg text-sm flex items-center space-x-2 ${
                uploadStatus.type === 'success' ? 'bg-green-100 text-status-success' : 'bg-red-100 text-status-danger'
                }`}>
                {uploadStatus.type === 'success' 
                    ? <CheckCircleIcon className="h-5 w-5" /> 
                    : <ExclamationTriangleIcon className="h-5 w-5" />}
                <span>{uploadStatus.message}</span>
                </div>
            )}

            <button 
                onClick={handleBulkUpload}
                disabled={!bulkFile || isUploading}
                className="w-full mt-6 bg-brand-primary text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center hover:bg-brand-secondary transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
                {isUploading ? (
                <>
                    <Spinner size="sm" />
                    <span className="ml-2">{addWatermark ? 'Uploading & Watermarking...' : 'Uploading...'}</span>
                </>
                ) : (
                'Upload Records'
                )}
            </button>
            </Card>
            
            <Card>
            <div className="flex items-center text-brand-primary mb-4">
                <FingerPrintIcon className="h-8 w-8 mr-3" />
                <h2 className="text-2xl font-bold">Watermark Existing Certificate</h2>
            </div>
            <p className="text-text-secondary mb-4">
                Upload a previously issued certificate to retroactively embed it with a secure digital watermark. This enhances the security of your older records.
            </p>
            <div className="p-6 bg-base-200 rounded-lg border border-base-300">
                <label htmlFor="watermark-upload" className="block text-sm font-medium text-text-primary mb-2">
                Upload Certificate File
                </label>
                <div className="flex items-center space-x-4">
                <input 
                    id="watermark-upload" 
                    type="file" 
                    accept="image/png, image/jpeg, image/webp, application/pdf"
                    onChange={handleWatermarkFileChange}
                    className="block w-full text-sm text-text-secondary file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-primary file:text-white hover:file:bg-brand-secondary cursor-pointer"
                />
                </div>
                <div className="mt-3 text-xs text-text-secondary">
                    <p>Supported formats: PNG, JPG, WEBP, PDF.</p>
                </div>
            </div>

            {watermarkStatus && (
                <div className={`mt-4 p-3 rounded-lg text-sm flex items-center space-x-2 ${
                watermarkStatus.type === 'success' ? 'bg-green-100 text-status-success' : 'bg-red-100 text-status-danger'
                }`}>
                {watermarkStatus.type === 'success' 
                    ? <CheckCircleIcon className="h-5 w-5" /> 
                    : <ExclamationTriangleIcon className="h-5 w-5" />}
                <span>{watermarkStatus.message}</span>
                </div>
            )}

            <button 
                onClick={handleApplyWatermark}
                disabled={!watermarkFile || isWatermarking}
                className="w-full mt-6 bg-brand-primary text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center hover:bg-brand-secondary transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
                {isWatermarking ? (
                <>
                    <Spinner size="sm" />
                    <span className="ml-2">Applying Watermark...</span>
                </>
                ) : (
                'Apply Watermark'
                )}
            </button>
            </Card>
            
            <Card className="lg:col-span-2">
            <div className="flex items-center text-brand-primary mb-4">
                <CodeBracketIcon className="h-8 w-8 mr-3" />
                <h2 className="text-2xl font-bold">Real-time API Integration</h2>
            </div>
            <p className="text-text-secondary mb-4">
                Integrate CertiVeri directly with your student information system (SIS) for real-time, automated certificate record uploads upon issuance.
            </p>
            <div className="p-4 bg-gray-800 rounded-lg text-sm font-mono text-gray-300">
                <p><span className="text-purple-400">POST</span> /api/v1/certificates</p>
                <p className="mt-2"><span className="text-green-400">Authorization:</span> Bearer &lt;YOUR_API_KEY&gt;</p>
                <p className="mt-2"><span className="text-yellow-400">Content-Type:</span> application/json</p>
                <p className="mt-4 text-gray-400">{`// Request Body`}</p>
                <p>{`{`}</p>
                <p className="pl-4">"studentName": "Jane Doe",</p>
                <p className="pl-4">"rollNumber": "UT-CSE-2025-102",</p>
                <p className="pl-4">...</p>
                <p>{`}`}</p>
            </div>
            <button className="w-full mt-6 bg-gray-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-gray-700 transition-colors">
                View API Documentation
            </button>
            </Card>
        </div>
      </div>
    </div>
  );
};

export default InstitutionPortal;