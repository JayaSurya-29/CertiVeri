import React, { useState, useCallback, useEffect } from 'react';
import { CertificateData, VerificationResult, SecurityAnalysis } from '../types';
import { extractDetailsFromImage, InvalidFileError } from '../services/geminiService';
import { UploadIcon, CheckCircleIcon, XCircleIcon, ExclamationTriangleIcon, DocumentMagnifyingGlassIcon, CubeTransparentIcon, ShieldCheckIcon, DocumentTextIcon, FingerPrintIcon } from './icons/Icons';
import Spinner from './common/Spinner';

interface VerifierProps {
  verifiedCertificates: CertificateData[];
}

/**
 * Simulates calling a blockchain API to check for a certificate record.
 * @param certificateId The ID of the certificate to check.
 * @returns A Promise resolving to 'VERIFIED' or 'NOT_FOUND'.
 */
const simulateBlockchainCheck = (certificateId: string): Promise<'VERIFIED' | 'NOT_FOUND'> => {
  return new Promise(resolve => {
    // Simulate network delay for the API call
    setTimeout(() => {
      // Simple mock logic for demonstration: if the certificate ID contains an even number,
      // we'll pretend it's found on the blockchain. This provides a mix of results.
      const hasEvenNumber = /\d*[02468]/.test(certificateId);
      if (hasEvenNumber) {
        resolve('VERIFIED');
      } else {
        resolve('NOT_FOUND');
      }
    }, 1000); // 1-second delay
  });
};


const Verifier: React.FC<VerifierProps> = ({ verifiedCertificates }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<VerificationResult | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setResult(null);
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      // Revoke the old URL to prevent memory leaks
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }

      if (file.type.startsWith('image/')) {
        setPreviewUrl(URL.createObjectURL(file));
      } else {
        setPreviewUrl(null); // Clear preview for non-image files like PDFs
      }
    }
  };

  useEffect(() => {
    // Cleanup the object URL when the component unmounts
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = error => reject(error);
    });
  };

  const handleVerify = useCallback(async () => {
    if (!selectedFile) return;

    setIsLoading(true);
    setResult(null);

    const normalizeString = (str: string | number): string => {
        if (typeof str === 'number') str = String(str);
        if (typeof str !== 'string') return '';
        return str
            .toLowerCase()
            .replace(/\([^)]*\)/g, '')
            .replace(/[.,/#!$%^&*;:{}=`~()]/g, "")
            .replace(/\s+/g, ' ')
            .trim();
    };

    try {
      const base64Image = await fileToBase64(selectedFile);
      const extractedData = await extractDetailsFromImage(base64Image, selectedFile.type);

      if (!extractedData.id) {
          setResult({
              status: 'ERROR',
              error: 'Could not extract Certificate ID. Please try a clearer image or document.',
              extractedData,
          });
          return;
      }
      
      const dbRecord = verifiedCertificates.find(cert => normalizeString(cert.id) === normalizeString(extractedData.id!));

      if (!dbRecord) {
        setResult({
          status: 'NOT_FOUND',
          extractedData,
          databaseRecord: null,
          blockchainStatus: 'NOT_FOUND',
        });
        return;
      }

      const mismatchedFields: (keyof CertificateData)[] = [];
      let isTextMismatch = false;

      (Object.keys(extractedData) as (keyof CertificateData)[]).forEach(key => {
        if (key in dbRecord && typeof dbRecord[key] !== 'object') {
            const extractedValue = normalizeString(extractedData[key] as string | number);
            const dbValue = normalizeString(dbRecord[key] as string | number);
            
            if (extractedValue && dbValue && extractedValue !== dbValue) {
                mismatchedFields.push(key);
                isTextMismatch = true;
            }
        }
      });
      
      let securityFailureReason = '';
      if (!extractedData.securityAnalysis?.hasQrCode) {
        securityFailureReason = "Critical security feature (QR Code) is missing.";
      } else if (!extractedData.securityAnalysis?.hasSignature) {
        securityFailureReason = "Official signature is missing.";
      }

      if (isTextMismatch || securityFailureReason) {
        let failureReason = '';
        if (isTextMismatch) {
            failureReason += `Data mismatch in the following fields: ${mismatchedFields.join(', ')}.`;
        }
        if (securityFailureReason) {
            if (failureReason) failureReason += ` Additionally, ${securityFailureReason}`;
            else failureReason = securityFailureReason;
        }

        setResult({
          status: 'FORGERY_DETECTED',
          extractedData,
          databaseRecord: dbRecord,
          mismatchedFields,
          blockchainStatus: 'NOT_FOUND',
          failureReason: failureReason
        });
      } else {
        // DB verification passed, now check blockchain
        const blockchainStatus = await simulateBlockchainCheck(dbRecord.id);
        setResult({
          status: 'VERIFIED',
          extractedData,
          databaseRecord: dbRecord,
          mismatchedFields: [],
          blockchainStatus: blockchainStatus,
        });
      }

    } catch (error) {
      if (error instanceof InvalidFileError) {
        setResult({
          status: 'INVALID_FILE',
          error: error.message,
        });
      } else {
        setResult({
          status: 'ERROR',
          error: error instanceof Error ? error.message : "An unknown error occurred."
        });
      }
    } finally {
      setIsLoading(false);
    }
  }, [selectedFile, verifiedCertificates]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="bg-base-100 p-6 rounded-xl shadow-lg">
        <h2 className="text-2xl font-bold text-text-primary mb-4 flex items-center">
          <DocumentMagnifyingGlassIcon className="h-7 w-7 mr-2 text-brand-primary" />
          Upload Certificate for Verification
        </h2>
        <div 
          className="border-2 border-dashed border-base-300 rounded-lg p-6 text-center bg-base-200 cursor-pointer hover:border-brand-primary transition-colors min-h-[250px] flex justify-center items-center"
          onClick={() => document.getElementById('file-upload')?.click()}
        >
          <input id="file-upload" type="file" className="hidden" accept="image/png, image/jpeg, image/webp, application/pdf" onChange={handleFileChange} />
          {previewUrl ? (
             <div>
                <img src={previewUrl} alt="Certificate Preview" className="max-h-60 mx-auto rounded-md shadow-md" />
                <p className="text-center mt-2 text-sm text-text-secondary">{selectedFile?.name}</p>
            </div>
          ) : selectedFile?.type === 'application/pdf' ? (
            <div className="flex flex-col items-center text-text-secondary">
                <DocumentTextIcon className="h-16 w-16 text-status-danger"/>
                <p className="mt-2 font-semibold text-text-primary">{selectedFile.name}</p>
            </div>
          ) : (
            <div className="flex flex-col items-center text-text-secondary">
              <UploadIcon className="h-12 w-12 mb-2" />
              <p className="font-semibold">Click to upload or drag & drop</p>
              <p className="text-sm">PNG, JPG, WEBP, PDF (max 10MB)</p>
            </div>
          )}
        </div>
        <button
          onClick={handleVerify}
          disabled={!selectedFile || isLoading}
          className="w-full mt-6 bg-brand-primary text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center space-x-2 hover:bg-brand-secondary transition-transform transform hover:scale-105 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:scale-100"
        >
          {isLoading ? <Spinner /> : <ShieldCheckIcon className="h-6 w-6" />}
          <span>{isLoading ? 'Verifying...' : 'Verify Certificate'}</span>
        </button>
      </div>

      <div className="bg-base-100 p-6 rounded-xl shadow-lg">
        <h2 className="text-2xl font-bold text-text-primary mb-4">Verification Result</h2>
        {!result && !isLoading && <InitialState />}
        {isLoading && <div className="flex justify-center items-center h-full"><Spinner size="lg" /></div>}
        {result && <ResultDisplay result={result} />}
      </div>
    </div>
  );
};

const InitialState = () => (
  <div className="flex flex-col items-center justify-center h-full text-center text-text-secondary p-4 bg-base-200 rounded-lg">
    <DocumentMagnifyingGlassIcon className="h-16 w-16 mb-4 text-gray-400" />
    <h3 className="text-lg font-semibold">Awaiting Certificate Upload</h3>
    <p>Please upload a certificate file to begin the verification process.</p>
  </div>
);

const ResultDisplay = ({ result }: { result: VerificationResult }) => {
    const statusConfig = {
        VERIFIED: {
            bgColor: 'bg-green-100', textColor: 'text-status-success', borderColor: 'border-status-success',
            icon: <CheckCircleIcon className="h-8 w-8" />, title: 'Certificate Verified'
        },
        FORGERY_DETECTED: {
            bgColor: 'bg-red-100', textColor: 'text-status-danger', borderColor: 'border-status-danger',
            icon: <XCircleIcon className="h-8 w-8" />, title: 'Forgery Detected'
        },
        NOT_FOUND: {
            bgColor: 'bg-yellow-100', textColor: 'text-status-warning', borderColor: 'border-status-warning',
            icon: <ExclamationTriangleIcon className="h-8 w-8" />, title: 'Certificate Not Found in Database'
        },
        INVALID_FILE: {
            bgColor: 'bg-yellow-100', textColor: 'text-status-warning', borderColor: 'border-status-warning',
            icon: <ExclamationTriangleIcon className="h-8 w-8" />, title: 'Invalid File'
        },
        ERROR: {
            bgColor: 'bg-red-100', textColor: 'text-status-danger', borderColor: 'border-status-danger',
            icon: <XCircleIcon className="h-8 w-8" />, title: 'Verification Error'
        }
    };

    const config = statusConfig[result.status];

    return (
        <div className="space-y-4">
            <div className={`p-4 rounded-lg border-l-4 ${config.borderColor} ${config.bgColor} ${config.textColor} flex items-start space-x-4`}>
                <div className="flex-shrink-0">{config.icon}</div>
                <div>
                    <h3 className="font-bold text-lg">{config.title}</h3>
                    {result.failureReason && <p className="text-sm mt-1"><b>Reason:</b> {result.failureReason}</p>}
                    {(result.status === 'ERROR' || result.status === 'INVALID_FILE') && <p className="text-sm mt-1">{result.error}</p>}
                </div>
            </div>

            {result.extractedData?.securityAnalysis && (
                <SecurityFeaturesCheck analysis={result.extractedData.securityAnalysis} notes={result.extractedData.analysisNotes} />
            )}

            {result.extractedData && (
                <ComparisonTable title="Extracted vs. Database Record" extracted={result.extractedData} database={result.databaseRecord} mismatched={result.mismatchedFields} />
            )}
            
            {(result.blockchainStatus === 'VERIFIED' || result.blockchainStatus === 'NOT_FOUND') && (
                <BlockchainStatus status={result.blockchainStatus} certificateId={result.databaseRecord?.id} />
            )}
        </div>
    );
};

const SecurityFeaturesCheck = ({ analysis, notes }: { analysis: SecurityAnalysis, notes?: string }) => {
    const Feature = ({ label, present }: { label: string, present: boolean }) => (
        <div className="flex items-center space-x-2">
            {present
                ? <CheckCircleIcon className="h-5 w-5 text-status-success" />
                : <XCircleIcon className="h-5 w-5 text-status-danger" />
            }
            <span className={present ? 'text-text-primary' : 'text-status-danger'}>{label}</span>
        </div>
    );
    return (
        <div className="border border-base-300 rounded-lg">
            <h4 className="text-md font-semibold text-text-primary p-3 bg-base-200 flex items-center">
                <FingerPrintIcon className="h-5 w-5 mr-2"/>
                Security Features Analysis
            </h4>
            <div className="p-3 space-y-2">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    <Feature label="QR Code" present={analysis.hasQrCode} />
                    <Feature label="Signature" present={analysis.hasSignature} />
                    <Feature label="Official Seal" present={analysis.hasSeal} />
                </div>
                {notes && (
                    <div className="pt-2 mt-2 border-t border-base-300">
                        <p className="text-xs text-text-secondary"><b className="font-medium">AI Notes:</b> {notes}</p>
                    </div>
                )}
            </div>
        </div>
    );
};

const BlockchainStatus = ({ status, certificateId }: { status: 'VERIFIED' | 'NOT_FOUND', certificateId?: string }) => {
    // Simple hash function to generate a pseudo-random tx hash for demonstration
    const generateTxHash = (id: string) => {
        let hash = 0;
        if (id.length === 0) return '0x...';
        for (let i = 0; i < id.length; i++) {
            const char = id.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0; // Convert to 32bit integer
        }
        const hex = Math.abs(hash).toString(16);
        return `0x${hex.slice(0, 8)}...${hex.slice(-4)}`;
    }

    if (status === 'VERIFIED') {
        const txHash = certificateId ? generateTxHash(certificateId) : '0x1a2b3c4d...9e0f1a2b';
        return (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center space-x-3">
                <CubeTransparentIcon className="h-7 w-7 text-blue-500"/>
                <div>
                    <p className="font-semibold text-blue-800">Blockchain Record: Verified</p>
                    <p className="text-xs text-blue-600 truncate" title={txHash}>Tx: {txHash}</p>
                </div>
            </div>
        )
    }
    return (
        <div className="p-3 bg-gray-100 border border-gray-200 rounded-lg flex items-center space-x-3">
            <CubeTransparentIcon className="h-7 w-7 text-gray-400"/>
            <div>
                <p className="font-semibold text-gray-700">Blockchain Record: Not Found</p>
                <p className="text-xs text-gray-500">This certificate has not been anchored to the blockchain.</p>
            </div>
        </div>
    );
};


const ComparisonTable = ({ title, extracted, database, mismatched }: {
    title: string;
    extracted: Partial<CertificateData>;
    database?: CertificateData | null;
    mismatched?: (keyof CertificateData)[];
}) => {
    const fields: { key: keyof CertificateData; label: string }[] = [
        { key: 'id', label: 'Certificate ID' },
        { key: 'studentName', label: 'Student Name' },
        { key: 'rollNumber', label: 'Roll Number' },
        { key: 'degree', label: 'Degree' },
        { key: 'institution', label: 'Institution' },
        { key: 'graduationYear', label: 'Graduation Year' },
        { key: 'marks', label: 'Marks/GPA' },
    ];
    
    return (
        <div className="border border-base-300 rounded-lg overflow-hidden">
            <h4 className="text-md font-semibold text-text-primary p-3 bg-base-200">{title}</h4>
            <div className="overflow-x-auto">
                <table className="w-full text-sm min-w-[500px]">
                    <thead className="bg-base-200/50 text-left text-text-secondary">
                        <tr>
                            <th className="p-2 font-semibold w-1/3">Field</th>
                            <th className="p-2 font-semibold">Extracted (from File)</th>
                            <th className="p-2 font-semibold">Database Record</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-base-300">
                        {fields.map(({ key, label }) => {
                            const isMismatched = mismatched?.includes(key);
                            const extractedValue = extracted[key] ?? <span className="text-gray-400">Not found</span>;
                            const dbValue = database ? database[key] : <span className="text-gray-400">N/A</span>;
                            return (
                                <tr key={key} className={isMismatched ? 'bg-red-50' : ''}>
                                    <td className="p-2 font-medium">
                                        <div className="flex items-center">
                                            {isMismatched && <ExclamationTriangleIcon className="h-4 w-4 mr-2 text-status-danger flex-shrink-0" />}
                                            <span>{label}</span>
                                        </div>
                                    </td>
                                    <td className={`p-2 font-mono text-xs ${isMismatched ? 'text-red-600 font-bold' : ''}`}>{String(extractedValue)}</td>
                                    <td className={`p-2 font-mono text-xs ${isMismatched ? 'text-green-700 font-bold' : ''}`}>{String(dbValue)}</td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Verifier;