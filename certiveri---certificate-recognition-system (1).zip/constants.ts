import { CertificateData, VerificationLogEntry, AdminStats } from './types';

// Mock database of verified certificates
export const INITIAL_VERIFIED_CERTIFICATES: CertificateData[] = [
  {
    id: 'CERT-UNIV-TECH-2023-001',
    studentName: 'Alice Johnson',
    rollNumber: 'UT-CSE-2023-101',
    degree: 'Bachelor of Science in Computer Science',
    institution: 'University of Technology',
    graduationYear: 2023,
    marks: '88.5%',
  },
  {
    id: 'CERT-CITY-COLL-2022-045',
    studentName: 'Bob Williams',
    rollNumber: 'CC-BBA-2022-205',
    degree: 'Bachelor of Business Administration',
    institution: 'City College of Commerce',
    graduationYear: 2022,
    marks: '3.9 GPA',
  },
  {
    id: 'CERT-INSTATE-ENG-2024-089',
    studentName: 'Charlie Brown',
    rollNumber: 'IE-MECH-2024-310',
    degree: 'Master of Engineering in Mechanical',
    institution: 'Institute of State Engineering',
    graduationYear: 2024,
    marks: '9.2 CGPA',
  },
  {
    id: 'BSEAP-SSC-2018-459821',
    studentName: 'David Miller',
    rollNumber: '1805123456',
    degree: 'Secondary School Certificate',
    institution: 'Board of Secondary Education Andhra Pradesh',
    graduationYear: 2018,
    marks: '9.5 GPA',
  },
];

// Mock data for admin dashboard
export const MOCK_ADMIN_STATS: AdminStats = {
  verificationsToday: 142,
  forgeryRate: 7.8,
  totalVerifications: 28541,
  averageTime: 25, // in seconds
};

export const MOCK_VERIFICATION_ACTIVITY = [
    { name: 'Mon', verifications: 120, forgeries: 10 },
    { name: 'Tue', verifications: 150, forgeries: 12 },
    { name: 'Wed', verifications: 130, forgeries: 8 },
    { name: 'Thu', verifications: 180, forgeries: 15 },
    { name: 'Fri', verifications: 220, forgeries: 20 },
    { name: 'Sat', verifications: 90, forgeries: 5 },
    { name: 'Sun', verifications: 75, forgeries: 3 },
];

export const MOCK_OUTCOMES_DATA = [
    { name: 'Verified', value: 85, fill: '#2E7D32' },
    { name: 'Forgery Detected', value: 8, fill: '#C62828' },
    { name: 'Not Found', value: 7, fill: '#F9A825' },
];

export const MOCK_FORGERY_LOGS: VerificationLogEntry[] = [
    { id: 'V-987234', timestamp: '2023-10-27 14:30', status: 'FORGERY_DETECTED', institution: 'University of Technology', verifier: 'TechCorp HR' },
    { id: 'V-987210', timestamp: '2023-10-27 11:15', status: 'FORGERY_DETECTED', institution: 'City College of Commerce', verifier: 'Global Consultants' },
    { id: 'V-987155', timestamp: '2023-10-26 18:05', status: 'FORGERY_DETECTED', institution: 'Unknown', verifier: 'State Agency' },
];