
import React, { useState } from 'react';
import Verifier from './components/Verifier';
import InstitutionPortal from './components/InstitutionPortal';
import AdminDashboard from './components/AdminDashboard';
import { ShieldCheckIcon, BuildingOfficeIcon, ChartBarIcon, DocumentCheckIcon } from './components/icons/Icons';
import { CertificateData } from './types';
import { INITIAL_VERIFIED_CERTIFICATES } from './constants';

type View = 'verifier' | 'institution' | 'admin';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('verifier');
  const [verifiedCertificates, setVerifiedCertificates] = useState<CertificateData[]>(INITIAL_VERIFIED_CERTIFICATES);

  const addCertificate = (newCertificate: CertificateData) => {
    // Prevent adding duplicates based on certificate ID
    if (!verifiedCertificates.some(cert => cert.id === newCertificate.id)) {
        setVerifiedCertificates(prevCerts => [...prevCerts, newCertificate]);
    }
  };

  const NavButton = ({ view, label, icon }: { view: View; label: string; icon: JSX.Element }) => (
    <button
      onClick={() => setCurrentView(view)}
      className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
        currentView === view
          ? 'bg-brand-primary text-white shadow-lg'
          : 'text-gray-200 hover:bg-brand-secondary hover:text-white'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-base-200 text-text-primary">
      <header className="bg-brand-secondary text-white shadow-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center space-x-3">
              <DocumentCheckIcon className="h-10 w-10 text-white" />
              <h1 className="text-2xl font-bold tracking-tight">CertiVeri</h1>
            </div>
            <nav className="hidden md:flex items-center space-x-2 bg-brand-accent p-2 rounded-lg">
              <NavButton view="verifier" label="Verifier" icon={<ShieldCheckIcon className="h-5 w-5" />} />
              <NavButton view="institution" label="Institution Portal" icon={<BuildingOfficeIcon className="h-5 w-5" />} />
              <NavButton view="admin" label="Admin Dashboard" icon={<ChartBarIcon className="h-5 w-5" />} />
            </nav>
          </div>
        </div>
      </header>
      
      <main className="container mx-auto p-4 sm:p-6 lg:p-8">
        {currentView === 'verifier' && <Verifier verifiedCertificates={verifiedCertificates} />}
        {currentView === 'institution' && <InstitutionPortal verifiedCertificates={verifiedCertificates} addCertificate={addCertificate} />}
        {currentView === 'admin' && <AdminDashboard />}
      </main>
      
      <footer className="text-center py-4 text-text-secondary text-sm">
        <p>&copy; {new Date().getFullYear()} CertiVeri. All rights reserved.</p>
        <p className="mt-1">Ensuring data privacy and security in compliance with global standards.</p>
      </footer>

      {/* Mobile Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-t-lg border-t border-gray-200">
        <div className="flex justify-around py-2">
            <MobileNavButton view="verifier" label="Verify" icon={<ShieldCheckIcon className="h-6 w-6" />} currentView={currentView} setCurrentView={setCurrentView} />
            <MobileNavButton view="institution" label="Institution" icon={<BuildingOfficeIcon className="h-6 w-6" />} currentView={currentView} setCurrentView={setCurrentView} />
            <MobileNavButton view="admin" label="Admin" icon={<ChartBarIcon className="h-6 w-6" />} currentView={currentView} setCurrentView={setCurrentView} />
        </div>
      </div>
    </div>
  );
};

const MobileNavButton = ({ view, label, icon, currentView, setCurrentView }: { view: View, label: string, icon: JSX.Element, currentView: View, setCurrentView: (view: View) => void }) => (
    <button onClick={() => setCurrentView(view)} className={`flex flex-col items-center justify-center w-full transition-colors duration-200 ${currentView === view ? 'text-brand-primary' : 'text-gray-500'}`}>
        {icon}
        <span className="text-xs">{label}</span>
    </button>
)

export default App;
