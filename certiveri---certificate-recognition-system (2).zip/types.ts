
export interface CertificateData {
  id: string;
  studentName: string;
  rollNumber: string;
  degree: string;
  institution: string;
  graduationYear: number;
  marks: string; // e.g., "85%" or "3.8 GPA"
}

export interface SecurityAnalysis {
    hasQrCode: boolean;
    hasSignature: boolean;
    hasSeal: boolean;
}

export interface ExtractedCertificateDetails extends Partial<CertificateData> {
    isCertificate?: boolean;
    securityAnalysis?: SecurityAnalysis;
    analysisNotes?: string;
}

export interface VerificationResult {
  status: 'VERIFIED' | 'FORGERY_DETECTED' | 'NOT_FOUND' | 'ERROR' | 'INVALID_FILE';
  extractedData?: ExtractedCertificateDetails;
  databaseRecord?: CertificateData | null;
  mismatchedFields?: (keyof CertificateData)[];
  blockchainStatus?: 'VERIFIED' | 'NOT_FOUND';
  failureReason?: string;
  error?: string;
}

export interface AdminStats {
  verificationsToday: number;
  forgeryRate: number;
  totalVerifications: number;
  averageTime: number;
}

export interface VerificationLogEntry {
  id: string;
  timestamp: string;
  status: 'VERIFIED' | 'FORGERY_DETECTED' | 'NOT_FOUND';
  institution: string;
  verifier: string;
}