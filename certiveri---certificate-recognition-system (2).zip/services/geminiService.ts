import { GoogleGenAI, Type } from "@google/genai";
import { CertificateData, ExtractedCertificateDetails } from '../types';

if (!process.env.API_KEY) {
  // In a real app, this would be a fatal error.
  // For this prototype, we'll log a warning.
  // The user will be alerted in the UI if the API key is missing.
  console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

// Custom error for non-certificate files, allowing for specific catch blocks.
export class InvalidFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidFileError';
  }
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const extractCertificateDetailsPrompt = `
You are an expert Optical Character Recognition (OCR) and document analysis system for academic certificates.
Your task is to analyze the provided image and perform two steps: validation and extraction.

**Step 1: Validate Document Type**
First, determine if the image is a formal academic or professional certificate.
- If it **IS NOT** a certificate (e.g., it's a photo of a person, a landscape, a receipt, an irrelevant document), set the 'isCertificate' flag to \`false\`, provide a brief explanation in 'analysisNotes', and do not extract any other data.
- If it **IS** a certificate, set the 'isCertificate' flag to \`true\` and proceed to Step 2.

**Step 2: Extract and Analyze (only if 'isCertificate' is true)**

Part A: Data Extraction
Extract the following key details:
- Student's Full Name
- Roll Number or Student ID
- Certificate ID or Serial Number
- Degree or Qualification Name
- Issuing Institution Name
- Graduation Year
- Marks, GPA, or CGPA

Part B: Security Analysis
Analyze the document for the presence of the following features. Return true if present, false otherwise.
- A QR Code
- An official signature (handwritten or digital)
- An official seal, emblem, or logo of the institution

Also, provide brief notes on any visual anomalies, signs of tampering, low resolution, or missing security features if it is a certificate.

Important Instructions:
1.  **Standardize Data:** Normalize extracted text. For example, "BOARD OF SECONDARY EDUCATION ANDHRA PRADESH, INDIA" becomes "Board of Secondary Education Andhra Pradesh India". Remove unnecessary punctuation but keep essential hyphens. "Secondary School Certificate (SSC)" should be extracted as "Secondary School Certificate".
2.  **Accuracy is Key:** Analyze the file carefully and return all information in a structured JSON format.
3.  **No Missing Fields:** If a textual field is not present, return null for that field.
4.  **No Fabrication:** Do not invent or infer information that is not explicitly on the certificate.
`;

export const extractDetailsFromImage = async (
  base64Image: string,
  mimeType: string
): Promise<ExtractedCertificateDetails> => {
  if (!process.env.API_KEY) {
    throw new Error("Gemini API key is not configured.");
  }
  
  try {
    const filePart = {
      inlineData: {
        data: base64Image,
        mimeType: mimeType,
      },
    };

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: { parts: [{ text: extractCertificateDetailsPrompt }, filePart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isCertificate: { type: Type.BOOLEAN, description: "True if the document is a certificate, otherwise false." },
            studentName: { type: Type.STRING },
            rollNumber: { type: Type.STRING },
            id: { type: Type.STRING, description: "Certificate ID or Serial Number" },
            degree: { type: Type.STRING },
            institution: { type: Type.STRING },
            graduationYear: { type: Type.INTEGER },
            marks: { type: Type.STRING, description: "GPA, CGPA, or Percentage" },
            securityAnalysis: {
                type: Type.OBJECT,
                description: "Analysis of the document's security features.",
                properties: {
                    hasQrCode: { type: Type.BOOLEAN },
                    hasSignature: { type: Type.BOOLEAN },
                    hasSeal: { type: Type.BOOLEAN },
                }
            },
            analysisNotes: { type: Type.STRING, description: "Notes on validation failure, visual inconsistencies, or signs of tampering."}
          },
          required: ["isCertificate"],
        },
      },
    });

    const jsonText = response.text.trim();
    const parsedData = JSON.parse(jsonText) as ExtractedCertificateDetails & { isCertificate?: boolean };
    
    // Step 1: Validate if the document is a certificate
    if (parsedData.isCertificate === false) {
      throw new InvalidFileError(parsedData.analysisNotes || "Invalid File: The uploaded file does not appear to be a certificate.");
    }
    
    // The Gemini API might return null for fields it can't find.
    // We create a clean object without null values.
    const cleanedData: Partial<CertificateData> = {};
    const textFields: (keyof CertificateData)[] = ['studentName', 'rollNumber', 'id', 'degree', 'institution', 'graduationYear', 'marks'];

    textFields.forEach(key => {
        if (parsedData[key] !== null && parsedData[key] !== undefined) {
             // Casting to `any` to dynamically assign properties.
            (cleanedData as any)[key] = parsedData[key];
        }
    });

    return { ...cleanedData, securityAnalysis: parsedData.securityAnalysis, analysisNotes: parsedData.analysisNotes };

  } catch (error) {
    console.error("Error processing file with Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            throw new Error("The provided Gemini API key is invalid. Please check your configuration.");
        }
        // Re-throw specific validation errors from the AI or other processing errors
        throw error;
    }
    throw new Error("Failed to process the uploaded file.");
  }
};