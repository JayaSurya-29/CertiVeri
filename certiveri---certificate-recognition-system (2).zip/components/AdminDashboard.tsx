
import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { MOCK_ADMIN_STATS, MOCK_VERIFICATION_ACTIVITY, MOCK_OUTCOMES_DATA, MOCK_FORGERY_LOGS } from '../constants';
import { AdminStats, VerificationLogEntry } from '../types';
import Card from './common/Card';
import { ChartBarIcon, ClockIcon, MagnifyingGlassIcon, ExclamationTriangleIcon, ShieldExclamationIcon, UserPlusIcon } from './icons/Icons';

const AdminDashboard: React.FC = () => {
    const [stats] = useState<AdminStats>(MOCK_ADMIN_STATS);
    const [logs] = useState<VerificationLogEntry[]>(MOCK_FORGERY_LOGS);
    const [blacklisted, setBlacklisted] = useState<string[]>(['Rogue International University']);
    const [newBlacklistEntry, setNewBlacklistEntry] = useState('');

    const handleAddBlacklist = () => {
        if (newBlacklistEntry && !blacklisted.includes(newBlacklistEntry)) {
            setBlacklisted([...blacklisted, newBlacklistEntry]);
            setNewBlacklistEntry('');
        }
    };

    return (
        <div className="space-y-8">
            <h1 className="text-4xl font-extrabold text-brand-primary">Administrator Dashboard</h1>
            
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard icon={<MagnifyingGlassIcon className="h-8 w-8 text-blue-500" />} label="Verifications Today" value={stats.verificationsToday} />
                <StatCard icon={<ShieldExclamationIcon className="h-8 w-8 text-red-500" />} label="Forgery Rate" value={`${stats.forgeryRate}%`} />
                <StatCard icon={<ChartBarIcon className="h-8 w-8 text-green-500" />} label="Total Verifications" value={stats.totalVerifications.toLocaleString()} />
                <StatCard icon={<ClockIcon className="h-8 w-8 text-yellow-500" />} label="Avg. Verification Time" value={`${stats.averageTime}s`} />
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                <Card className="lg:col-span-3">
                    <h2 className="text-xl font-bold mb-4">Weekly Verification Activity</h2>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={MOCK_VERIFICATION_ACTIVITY}>
                            <XAxis dataKey="name" stroke="#616161" />
                            <YAxis stroke="#616161" />
                            <Tooltip wrapperClassName="!bg-base-100 !border-base-300 !rounded-lg !shadow-lg" />
                            <Legend />
                            <Bar dataKey="verifications" fill="#1976D2" name="Verified" />
                            <Bar dataKey="forgeries" fill="#C62828" name="Forgeries" />
                        </BarChart>
                    </ResponsiveContainer>
                </Card>
                <Card className="lg:col-span-2">
                    <h2 className="text-xl font-bold mb-4">Verification Outcomes</h2>
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie data={MOCK_OUTCOMES_DATA} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                                {MOCK_OUTCOMES_DATA.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} />)}
                            </Pie>
                            <Tooltip wrapperClassName="!bg-base-100 !border-base-300 !rounded-lg !shadow-lg" />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </Card>
            </div>

             {/* Logs and Blacklist */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                    <h2 className="text-xl font-bold mb-4 flex items-center"><ExclamationTriangleIcon className="h-6 w-6 mr-2 text-status-danger" />Recent Forgery Alerts</h2>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-base-200 text-text-secondary">
                                <tr>
                                    <th className="p-3">Timestamp</th>
                                    <th className="p-3">Institution</th>
                                    <th className="p-3">Verifier</th>
                                </tr>
                            </thead>
                            <tbody>
                                {logs.map(log => (
                                    <tr key={log.id} className="border-b border-base-300">
                                        <td className="p-3">{log.timestamp}</td>
                                        <td className="p-3">{log.institution}</td>
                                        <td className="p-3">{log.verifier}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </Card>
                <Card>
                    <h2 className="text-xl font-bold mb-4">Offender Blacklist</h2>
                    <div className="flex space-x-2 mb-4">
                        <input
                            type="text"
                            value={newBlacklistEntry}
                            onChange={(e) => setNewBlacklistEntry(e.target.value)}
                            placeholder="Add institution or entity..."
                            className="flex-grow p-2 border border-base-300 rounded-md focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                        />
                        <button onClick={handleAddBlacklist} className="bg-brand-primary text-white p-2 rounded-md hover:bg-brand-secondary">
                            <UserPlusIcon className="h-6 w-6" />
                        </button>
                    </div>
                    <ul className="space-y-2">
                        {blacklisted.map((item, index) => (
                            <li key={index} className="bg-base-200 p-2 rounded-md text-text-secondary">{item}</li>
                        ))}
                    </ul>
                </Card>
            </div>
        </div>
    );
};

interface StatCardProps {
    icon: JSX.Element;
    label: string;
    value: string | number;
}

const StatCard: React.FC<StatCardProps> = ({ icon, label, value }) => (
    <Card className="flex items-center p-4">
        <div className="p-3 bg-base-200 rounded-full mr-4">{icon}</div>
        <div>
            <p className="text-sm text-text-secondary font-medium">{label}</p>
            <p className="text-2xl font-bold text-text-primary">{value}</p>
        </div>
    </Card>
);

export default AdminDashboard;
